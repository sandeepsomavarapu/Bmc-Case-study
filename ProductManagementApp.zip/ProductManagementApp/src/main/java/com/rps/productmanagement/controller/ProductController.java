package com.rps.productmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rps.productmanagement.model.Product;
import com.rps.productmanagement.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {

	@Autowired
	ProductService service;

	@PostMapping("/insert")//http://localhost:5000/products/insert
	public String insertProduct(@RequestBody Product product)
	{
		return service.addProduct(product);
	}
}
