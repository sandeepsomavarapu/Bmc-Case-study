package com.rps.productmanagement.dao;

import com.rps.productmanagement.model.Product;

public interface ProductDao {
	public abstract String addProduct(Product product);
}
