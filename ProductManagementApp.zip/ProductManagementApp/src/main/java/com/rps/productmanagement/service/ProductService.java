package com.rps.productmanagement.service;

import com.rps.productmanagement.model.Product;

public interface ProductService {

	public abstract String addProduct(Product product);
}
