package com.rps.productmanagement.dao;

import org.springframework.stereotype.Repository;

import com.rps.productmanagement.model.Product;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class ProductDaoImpl implements ProductDao {
	@PersistenceContext
	EntityManager entityManager;// JPA

	@Override
	public String addProduct(Product product) {
		entityManager.persist(product);
		return "Product Inserted Successfully";
	}

}
